# -*- coding: utf-8 -*-
"""Service Android : garde la connexion ouverte et affiche une notification à chaque message."""
import base64, json, os, time, unicodedata
from jnius import autoclass
import paho.mqtt.client as mqtt
from fernet_pur import Fernet, pbkdf2

BASE = os.environ.get("PYTHON_SERVICE_ARGUMENT") or os.environ.get("ANDROID_PRIVATE") or "."
DATA, FLAG, BOITE = (os.path.join(BASE, n) for n in ("jochat2.json", "actif.txt", "boite.jsonl"))
SERVEUR, PORT = "broker.hivemq.com", 1883
etat = {"data": {}}; cles = {}; vus = set(); abonnes = set()

def norm(s):
    return "".join(c for c in unicodedata.normalize("NFD", s.lower()) if unicodedata.category(c) != "Mn").strip()

def charger():
    try:
        with open(DATA, encoding="utf-8") as f: return json.load(f)
    except Exception:
        return {}

Svc = autoclass("org.kivy.android.PythonService").mService
NM = Svc.getSystemService(autoclass("android.content.Context").NOTIFICATION_SERVICE)
SDK = autoclass("android.os.Build$VERSION").SDK_INT

def init_canal():
    if SDK >= 26:
        c = autoclass("android.app.NotificationChannel")("jochat_msgs", "Messages Jochat", 4)
        c.enableVibration(True); NM.createNotificationChannel(c)

def notifier(titre, texte, cid):
    B = autoclass("android.app.Notification$Builder")
    b = B(Svc, "jochat_msgs") if SDK >= 26 else B(Svc)
    b.setContentTitle(titre); b.setContentText(texte); b.setAutoCancel(True)
    b.setSmallIcon(autoclass("android.R$drawable").stat_notify_chat)
    try:
        PI = autoclass("android.app.PendingIntent")
        launch = Svc.getPackageManager().getLaunchIntentForPackage(Svc.getPackageName())
        b.setContentIntent(PI.getActivity(Svc, 0, launch, PI.FLAG_IMMUTABLE | PI.FLAG_UPDATE_CURRENT))
    except Exception:
        pass
    NM.notify(abs(hash(cid)) % 100000, b.build())

def cle(cid, code):
    if cid not in cles:
        cles[cid] = Fernet(base64.urlsafe_b64encode(pbkdf2(code.encode(), b"jochat2", 100_000, 32)))
    return cles[cid]

def app_ouverte():
    try: return time.time() - os.path.getmtime(FLAG) < 6
    except Exception: return False

def on_message(client, ud, msg):
    try:
        cid = msg.topic.split("/", 1)[1]; d = etat["data"]; c = d.get("contacts", {}).get(cid)
        if not c:
            etat["data"] = d = charger(); c = d.get("contacts", {}).get(cid)
            if not c: return
        p = json.loads(cle(cid, c["code"]).decrypt(msg.payload))
        if p.get("t") not in ("msg", "med") or p.get("de") == norm(d.get("nom", "")): return
        if app_ouverte() or p.get("id") in vus: return
        vus.add(p.get("id"))
        with open(BOITE, "a", encoding="utf-8") as f: f.write(json.dumps({"cid": cid, "p": p}, ensure_ascii=False) + "\n")
        texte = p.get("texte", "") if p["t"] == "msg" else {"img": "Photo", "voc": "Message vocal", "stk": "Sticker"}.get(p.get("kind"), "Média")
        notifier(c.get("nom", "Jochat"), texte[:120], cid)
    except Exception:
        pass

def abonner(cl):
    for cid in etat["data"].get("contacts", {}):
        if cid not in abonnes:
            try: cl.subscribe("jochat2/" + cid, qos=1); abonnes.add(cid)
            except Exception: pass

def main():
    init_canal(); etat["data"] = charger()
    cid_c = "jochat-svc-" + etat["data"].get("client", "x")
    try: cl = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=cid_c, clean_session=False)
    except AttributeError: cl = mqtt.Client(client_id=cid_c, clean_session=False)
    cl.on_message = on_message
    cl.on_connect = lambda c, u, f, rc, p=None: (abonnes.clear(), abonner(c))
    cl.connect_async(SERVEUR, PORT, 60); cl.loop_start()
    while True:
        time.sleep(10)
        etat["data"] = charger(); abonner(cl)

main()
