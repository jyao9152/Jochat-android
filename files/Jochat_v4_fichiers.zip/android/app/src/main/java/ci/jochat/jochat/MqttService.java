package ci.jochat.jochat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Service au premier plan : garde la connexion ouverte et affiche une notification par message. */
public class MqttService extends Service {
    static final String BROKER = "tcp://broker.hivemq.com:1883";
    static MqttService inst;
    static final Set<Integer> ids = new HashSet<Integer>();

    private SharedPreferences prefs;
    private Thread th;
    private volatile boolean run = true;
    private volatile boolean reload = false;
    private PowerManager.WakeLock wl;

    static void start(Context c) {
        Intent i = new Intent(c, MqttService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static void reload() {
        if (inst != null) inst.reload = true;
    }

    static synchronized void push(Context c, String topic, String payload) {
        SharedPreferences p = c.getSharedPreferences("j", 0);
        try {
            JSONArray a = new JSONArray(p.getString("inbox", "[]"));
            JSONObject o = new JSONObject();
            o.put("topic", topic);
            o.put("payload", payload);
            a.put(o);
            while (a.length() > 30) a.remove(0);
            p.edit().putString("inbox", a.toString()).apply();
        } catch (Exception e) { }
    }

    static synchronized String takeInbox(Context c) {
        SharedPreferences p = c.getSharedPreferences("j", 0);
        String v = p.getString("inbox", "[]");
        p.edit().putString("inbox", "[]").apply();
        return v;
    }

    static void clearNotifs(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        synchronized (ids) {
            for (Integer id : ids) nm.cancel(id);
            ids.clear();
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        prefs = getSharedPreferences("j", 0);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("svc", "Connexion", NotificationManager.IMPORTANCE_LOW));
            NotificationChannel m = new NotificationChannel("msg", "Messages", NotificationManager.IMPORTANCE_HIGH);
            m.enableVibration(true);
            nm.createNotificationChannel(m);
        }
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jochat:svc");
            wl.acquire();
        } catch (Exception e) { }
    }

    private PendingIntent openApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification.Builder builder(String channel) {
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = builder("svc")
                .setContentTitle("Jochat")
                .setContentText("Connecté pour recevoir tes messages")
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setOngoing(true)
                .setContentIntent(openApp())
                .build();
        startForeground(1, n);
        if (th == null) {
            th = new Thread(new Runnable() {
                public void run() { loop(); }
            });
            th.start();
        }
        return START_STICKY;
    }

    private void loop() {
        String cid = prefs.getString("cid", "");
        if (cid.length() == 0) {
            cid = UUID.randomUUID().toString().replace("-", "");
            prefs.edit().putString("cid", cid).apply();
        }
        while (run) {
            MqttClient client = null;
            try {
                String topic = prefs.getString("topic", "");
                if (topic.length() == 0) { Thread.sleep(3000); continue; }
                reload = false;
                client = new MqttClient(BROKER, "jochat3-svc-" + cid, new MemoryPersistence());
                MqttConnectOptions o = new MqttConnectOptions();
                o.setCleanSession(false);
                o.setKeepAliveInterval(60);
                o.setConnectionTimeout(15);
                client.setCallback(new MqttCallback() {
                    public void connectionLost(Throwable t) { }
                    public void messageArrived(String tp, MqttMessage m) throws Exception {
                        onMsg(tp, new String(m.getPayload(), "UTF-8"));
                    }
                    public void deliveryComplete(IMqttDeliveryToken t) { }
                });
                client.connect(o);
                client.subscribe(topic, 1);
                while (run && !reload && client.isConnected()) Thread.sleep(2000);
            } catch (Exception e) {
                try { Thread.sleep(5000); } catch (Exception x) { }
            }
            try { if (client != null) { client.disconnectForcibly(); client.close(); } } catch (Exception e) { }
        }
    }

    private void onMsg(String topic, String payload) {
        if (MainActivity.visible) return;   // l'appli ouverte s'en occupe
        String name = "Jochat";
        try {
            JSONObject env = new JSONObject(payload);
            JSONObject cs = new JSONObject(prefs.getString("contacts", "{}"));
            String k = env.getString("k");
            if (cs.has(k)) name = cs.getString(k);
        } catch (Exception e) { }
        push(this, topic, payload);
        int id = Math.abs(name.hashCode()) % 100000 + 10;
        synchronized (ids) { ids.add(id); }
        Notification n = builder("msg")
                .setContentTitle(name)
                .setContentText("Nouveau message")
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setAutoCancel(true)
                .setContentIntent(openApp())
                .build();
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(id, n);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        run = false;
        inst = null;
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception e) { }
        super.onDestroy();
    }
}
